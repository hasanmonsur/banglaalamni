# pgw-merchant-backend-php
1. app_key/app_secret and username/password will be shared with merchants during pgw onboarding.
2. merchant should preapre own code-base using provided sample
3. merchant should go through https://developer.bka.sh/reference first for clear understanding about PGW APIs
